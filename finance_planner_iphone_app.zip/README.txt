PERSONAL FINANCE PLANNER — iPhone PWA

This is a web app package designed to be installed on iPhone's Home Screen.
For iPhone installation, the package must be served from an HTTPS website (not opened as a local file).

Files:
- index.html: app
- manifest.json: install metadata
- service-worker.js: offline caching
- icon.svg: app icon

Install:
1. Upload these files to a static HTTPS host (for example GitHub Pages, Netlify, or another web host).
2. Open the hosted index.html URL in Safari on your iPhone.
3. Tap Share > Add to Home Screen.
4. Enable "Open as Web App" if offered, then tap Add.

The app stores financial data locally in the browser/device. It does not sync to a cloud account. Export/Backup inside the app is recommended.
